/*

import 'package:dtt_real_estate_app/detailsPage.dart';
import 'package:dtt_real_estate_app/userHouses.dart';
import 'package:flutter/material.dart';


class HomeScreen extends StatelessWidget{
  final items = List.generate(50, (i) => i);
 HomeScreen({Key? key}) : super(key: key);


 loadHous() async{
    final results = await fetchAlbum();

 }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: const Text(
          "DTT REAL ESTATE")),
      ),
      body: Center(
        child: FutureBuilder<Album>(
          future: futureAlbum,
            builder: (context,snapshot) {
            if(snapshot.hasData) {
              return Text(snapshot.data!.title);
            } else if (snapshot.hasError) {
              return Text('${snapshot.error}');
            }

            // By default, show a loading spinner.
            return const CircularProgressIndicator();
            },
        ),
      )
            );
      }
  }

   openPage(context){
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => DetailsPage()));
   }
*/
