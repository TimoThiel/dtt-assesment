import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DetailsPage extends StatelessWidget{
const DetailsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: const Text(
            "DTT REAL ESTATE")),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () =>goBack(context),
          child: const Text('assets/Icons/ic_back.svg'),
        ),
      ),
    );
  }

  goBack(context){
    Navigator.pop(context);
  }
}