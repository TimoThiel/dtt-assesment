import 'package:dtt_real_estate_app/infoScreen.dart';
import 'package:dtt_real_estate_app/main.dart';
import 'package:dtt_real_estate_app/screens/HomeScreen.dart';
import 'package:dtt_real_estate_app/userHouses.dart';
import 'package:flutter/material.dart';

class Splash extends StatefulWidget{
  const Splash ({Key? key}) : super(key: key);
  @override
  State<Splash> createState() => _SplashState();
}
class _SplashState extends State<Splash> {
  @override
  void initState(){
    super.initState();
    _navigatetohome();
  }
// Here I make the slash screen go away to the next screen within 3500 milliseconds.
  _navigatetohome()async{
    await Future.delayed(Duration(milliseconds: 3500),(){});
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>MyHomePage()));
  }
// Here I made the scaffold with the DTT splash screen that was given and i changed the color to the color red of the DTT assets.
  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Colors.red[600],
        body: Center(
          child: Container(
            child: Image.asset('assets/images/launcher_icon.png')
          ),
        ),
    );
  }
}