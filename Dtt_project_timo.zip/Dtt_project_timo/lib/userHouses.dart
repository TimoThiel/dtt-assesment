import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';


Future<List<Hous>> fetchHousList() async {
  final api_key = '98bww4ezuzfePCYFxJEWyszbUXc7dxRx';
  final response = await http.get(
    Uri.parse('https://intern.d-tt.nl/api/house'),
    headers: {
      'Access-Key': api_key,
    },
  );
  print('Response: ${response.statusCode} - ${response.body}');
  if (response.statusCode == 200) {
    final List<dynamic> responseJson = jsonDecode(response.body);
    return responseJson.map((json) => Hous.fromJson(json)).toList();
  } else {
    print('API request failed with status code: ${response.statusCode}');
    throw Exception('Failed to load data');
  }
}

class Hous {
  final int id;
  final String image;
  final int price;
  final int bedrooms;
  final int bathrooms;
  final int size;
  final String description;
  final int latitude;
  final int longitude;
  final String zip;
  final String city;

  Hous({
    required this.id,
    required this.image,
    required this.price,
    required this.bedrooms,
    required this.bathrooms,
    required this.size,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.zip,
    required this.city,
  });

  factory Hous.fromJson(Map<String, dynamic> json) {
    return Hous(
      id: json['id'],
      image: json['image'],
      price: json['price'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      size: json['size'],
      description: json['description'],
      latitude: json['latitude'],
      longitude: json['longitude'],
      zip: json['zip'],
      city: json['city'],
    );
  }
}

void main() => runApp(const MyHous());

class MyHous extends StatelessWidget {
  const MyHous({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fetch Data Example',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: const HousListScreen(),
    );
  }
}

class HousListScreen extends StatelessWidget {
  const HousListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[600],
        title: const Text('DTT REAL ESTATE'),
        actions: [
          IconButton(
            onPressed: () {
              showSearch(context: context, delegate: CustomSearchDelegate());
            },
            icon: const Icon(Icons.search),
          ),
        ],
      ),
      body: FutureBuilder<List<Hous>>(
        future: fetchHousList(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            final sortedHouses = List.from(snapshot.data!)
              ..sort((a, b) => a.price.compareTo(b.price));

            return ListView.builder(
              itemCount: sortedHouses.length,
              itemBuilder: (context, index) {
                final house = sortedHouses[index];
                return GestureDetector(
                  onTap: (){
                    Navigator.push(context, 
                      MaterialPageRoute(builder: (context) => 
                          HouseDetailPage(house: house),),);
                  },
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 4.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          child: CachedNetworkImage( imageUrl:'https://intern.d-tt.nl${house.image}', fit: BoxFit.cover),
                        ),
                        SizedBox(width: 8.0),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Price: \$${house.price}'),
                            Text( house.zip +' '+ house.city),
                            Row(
                              children: [
                                Icon(Icons.bed),
                                SizedBox(width: 4.0),
                                Text('${house.bedrooms}'),
                                SizedBox(width: 16.0),
                                Icon(Icons.bathtub_outlined),
                                SizedBox(width: 4.0),
                                Text('${house.bathrooms}'),
                                SizedBox(width: 16.0),
                                Icon(Icons.layers),
                                SizedBox(width: 4.0),
                                Text('${house.size}'),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                );
              },

            );
          } else {
            return const Center(child: Text('No data available.'));
          }
        },
      ),
    );
  }
}

class HouseDetailPage extends StatelessWidget {
  final Hous house;

  HouseDetailPage({required this.house});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 200, // Pas de hoogte van de afbeelding aan zoals nodig
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: CachedNetworkImageProvider('https://intern.d-tt.nl${house.image}'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Positioned(
            top: 40,
            left: 16,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white,),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
          Positioned(
            top: 150, // Pas de positie van de Scaffold aan zoals nodig
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(20.0), // Pas de afronding aan zoals nodig
                ),
              ),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Price: \$${house.price}',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Row(
                        children: [
                          Icon(Icons.bed),
                          SizedBox(width: 5),
                          Text('${house.bedrooms}'),
                          Icon(Icons.bathtub_outlined),
                          SizedBox(width: 5),
                          Text('${house.bathrooms}', style: TextStyle(fontSize: 16)),
                          Icon(Icons.layers),
                          SizedBox(width: 5),
                          Text('${house.size}', style: TextStyle(fontSize: 16)),
                        ],
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Description',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Text('${house.description}', style: TextStyle(fontSize: 12)),
                      SizedBox(height: 10),
                      Text(
                        'Location',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      // Voeg hier andere details van het huis toe
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 340,
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              margin: EdgeInsets.only(top: 20), // Voeg de gewenste marges toe
              padding: EdgeInsets.all(16), // Voeg de gewenste opvulling toe
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(20.0),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Location',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  // Voeg hier andere details van het huis toe
                  // ... Andere widgets hier ...
                  SizedBox(height: 10),
                  Text(
                    'Map',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Container(
                    height: 200, // Pas de hoogte van de kaartcontainer aan zoals gewenst
                    child: GoogleMap(
                      initialCameraPosition: CameraPosition(
                        target: LatLng(house.latitude.toDouble(), house.longitude.toDouble()),
                        zoom: 14.0,
                      ),
                      markers: {
                        Marker(
                          markerId: MarkerId('house_location'),
                          position: LatLng(house.latitude.toDouble(), house.longitude.toDouble()),
                        ),
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),

        ],
      ),
    );
  }

}

class CustomSearchDelegate extends SearchDelegate {
  List<String> searchTerms = [

  ];

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        close(context, null);
      },
      icon: const Icon(Icons.arrow_back),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    List<String> matchQuery = [];
    for (var i in searchTerms) {
      if (i.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(i);
      }
    }
    return _buildSearchResults(matchQuery);
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    List<String> matchQuery = [];
    for (var i in searchTerms) {
      if (i.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(i);
      }
    }
    return _buildSearchResults(matchQuery);
  }

  Widget _buildSearchResults(List<String> results) {
    if (results.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/search_state_empty.png', // Voeg hier het pad naar je afbeelding toe
              width: 150,
              height: 150,
            ),
            const SizedBox(height: 10),
            Text(
              'No results found!',
              style: TextStyle(fontSize: 12),
            ),
            Text('Perhaps try another search?',
            style: TextStyle(fontSize: 12),)
          ],
        ),
      );
    } else {
      return ListView.builder(
        itemCount: results.length,
        itemBuilder: (context, index) {
          var result = results[index];
          return ListTile(
            title: Text(result),
          );
        },
      );
    }
  }
}
