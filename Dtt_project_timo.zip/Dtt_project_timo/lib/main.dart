import 'package:dtt_real_estate_app/splash.dart';
import 'package:dtt_real_estate_app/screens/HomeScreen.dart';
import 'package:flutter/material.dart';
import 'splash.dart';


void main(){
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context){
    return const MaterialApp(
        home: Splash()
    );
  }
}