import 'package:dtt_real_estate_app/userHouses.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bottom Navigation Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;

  // List of page widgets
  final List<Widget> _pages = [
    UserHouses(),
    InfoScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'Info',
          ),
        ],
      ),
    );
  }
}

class InfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[600],
        title: Center(child: Text('About')),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Padding(
            padding: EdgeInsets.all(14.0),
            child: Text(
              'This is an app for viewing houses. '
                  'The houses are presented by API. '
                  'If you pick a house you will see some description and every details from the price to the amount of bedrooms. '
                  'I also made the visuals a little more to my liking. '
                  'So now something about me. My name is Timo van der Thiel. '
                  'I am 21years old. I love to develop games and play games. Other hobbies I have are fishing and football. '
                  'I jus finished a theme semester about mobile development with android studio. This was about kotlin. '
                  'I am a person who is good in working with a team as well as working on my own. '
                  'If i need help I will ask for it and wont let it stop me to reach the end.',
            ),
          ),
          Expanded(
            child: Image.asset(
              'assets/images/launcher_icon.png', // Voeg het juiste pad naar je afbeelding toe

            ),
          ),
        ],
      ),
    );
  }
}

class UserHouses extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        home: MyHous()
    );
  }
}
