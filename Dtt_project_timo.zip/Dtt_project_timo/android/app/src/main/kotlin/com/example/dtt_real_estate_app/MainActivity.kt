package com.example.dtt_real_estate_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
